package com.diman.tugas_gis;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.location_map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //  tambah koordinat marker
        LatLng luwuk = new LatLng (-0.943405315628955, 122.79640131274348);
        LatLng nambo = new LatLng(-1.0774683120857043, 122.73465957110409);

//    atur ukuran marker
        int tinggi = 100;
        int lebar = 100;

        BitmapDrawable bitmapStart = (BitmapDrawable)getResources().getDrawable(R.drawable.noun_862185_cc);
        BitmapDrawable bitmapDes = (BitmapDrawable)getResources().getDrawable(R.drawable.noun_862185_cc);

        Bitmap s = bitmapStart.getBitmap();
        Bitmap d = bitmapDes.getBitmap();

        Bitmap markerStart = Bitmap.createScaledBitmap(s, lebar, tinggi, false);
        Bitmap markerDes = Bitmap.createScaledBitmap(d, lebar, tinggi, false);

//    tambahkan marker ke map
        mMap.addMarker(new MarkerOptions().position(luwuk).title("Marker in Rumah Sakit Claire Medika")
        .snippet("Ini salah satu rumah sakit yang berada di kota luwuk")
        .icon(BitmapDescriptorFactory.fromBitmap(markerStart)));

        mMap.addMarker(new MarkerOptions().position(nambo).title("Marker in nambo lempek")
                .snippet("Ini kampung saya teguh priansyah budin")
                .icon(BitmapDescriptorFactory.fromBitmap(markerDes)));

        mMap.addPolyline(new PolylineOptions().add(
                luwuk,
                new LatLng(-0.943558920417058, 122.79655171100329),
                new LatLng(-0.9457841399887689, 122.79343820936494),
                new LatLng(-0.948811773686361, 122.79214525164467),
                new LatLng(-0.9498857410094033, 122.79056198473218),
                new LatLng(-0.9528678951828831, 122.78821061346953),
                new LatLng(-0.9543242951217253, 122.78838401842405),
                new LatLng(-0.9557529535210705, 122.78924410703242),
                new LatLng(-0.9575561137611603, 122.78658060683998),
                new LatLng(-0.96126645968727, 122.7889042333026),
                new LatLng(-0.9619946579737515, 122.78906376586926),
                new LatLng(-0.9628893013263254, 122.78857823198564),
                new LatLng(-0.9671794330828808, 122.78755178766922),
                new LatLng(-0.9674799073990162, 122.78795498149513),
                new LatLng(-0.9681609824081193, 122.78773460226397),
                new LatLng(-0.968312303421477, 122.78801127395373),
                new LatLng(-0.9698542103186677, 122.78723404170812),
                new LatLng(-0.9771007999659115, 122.78571453827777),
                new LatLng(-0.9806397168501668, 122.78658117731469),
                new LatLng(-0.9859278206970518, 122.79178467525176),
                new LatLng(-1.0007111984141341, 122.79847654765052),
                new LatLng(-1.0077193953549202, 122.7960431395263),
                new LatLng(-1.0102846561744265, 122.79316007980253),
                new LatLng(-1.029061245289951, 122.77967053454508),
                new LatLng(-1.0502442787169264, 122.76512298559817),
                new LatLng(-1.058596220956969, 122.75333527262568),
                new LatLng(-1.062914985458514, 122.74875619824961),
                new LatLng(-1.0711332649290846, 122.74373119644265),
                nambo
        ).width(10)
                .color(Color.BLUE));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(luwuk, 11.5f));
    }
}
